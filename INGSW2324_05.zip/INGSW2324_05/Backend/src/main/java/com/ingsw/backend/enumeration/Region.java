package com.ingsw.backend.enumeration;

public enum Region {

	NOT_SPECIFIED,
	CAMPANIA,
    LAZIO,
    LOMBARDIA,
    VENETO,
    EMILIA_ROMAGNA,
    PIEMONTE,
    PUGLIA,
    TOSCANA,
    CALABRIA,
    SARDEGNA,
    SICILIA,
    MARCHE,
    ABRUZZO,
    FRIULI_VENEZIA_GIULIA,
    UMBRIA,
    BASILICATA,
    MOLISE,
    VALLE_D_AOSTA,
    TRENTINO_ALTO_ADIGE,
    LIGURIA
}
