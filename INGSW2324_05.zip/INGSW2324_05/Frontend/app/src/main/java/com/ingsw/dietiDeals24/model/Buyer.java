package com.ingsw.dietiDeals24.model;

public class Buyer extends User {
    public Buyer(Buyer buyer) {
        super(buyer);
    }
}
