package com.ingsw.backend.enumeration;

public enum Role {
	BUYER,
	SELLER
}
