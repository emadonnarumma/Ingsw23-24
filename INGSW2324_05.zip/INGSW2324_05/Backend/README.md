# Ingsw23-24
1. Generare il file .jar del server in questa cartella
2. Assicurarsi di essere nella directory con i file Dockerfile, docker-compose e il .jar appena generato
3. Eseguire il comando `docker-compose up --build`