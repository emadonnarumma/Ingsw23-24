package com.ingsw.backend.enumeration;

public enum Wear {
    NOT_SPECIFIED,
    NEW,
    VERY_GOOD_CONDITION,
    GOOD_CONDITION,
    BAD_CONDITION
}
