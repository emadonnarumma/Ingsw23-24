package com.ingsw.dietiDeals24.model.enumeration;

public enum BidStatus {
    ACCEPTED,
    DECLINED,
    PENDING,
    EXPIRED,
    PAYED
}
