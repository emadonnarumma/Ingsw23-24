package com.ingsw.backend.enumeration;

public enum BidStatus {
    ACCEPTED,
    DECLINED,
    PENDING,
    EXPIRED,
    PAYED
}
