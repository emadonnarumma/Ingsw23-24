package com.ingsw.backend.enumeration;

public enum AuctionStatus {
    SUCCESSFUL ,
    IN_PROGRESS,
    FAILED
}
